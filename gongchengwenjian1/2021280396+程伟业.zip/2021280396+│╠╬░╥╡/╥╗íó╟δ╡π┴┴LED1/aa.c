#include<reg52.h>
sbit led1=P0^5;
void main(){
	led1=0;
}